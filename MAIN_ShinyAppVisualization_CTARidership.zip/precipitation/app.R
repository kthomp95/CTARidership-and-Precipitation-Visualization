#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(dplyr)          #Tools for cleaning data
library(here)           #File path management
library(ggplot2)        #Data visualization
library(sf)             #transform shapefile to lat long
library(stringr)        #string manipulation
library(lubridate)      #time date manipulation
library(raster)         #saving shapefiles
#install.packages("rgdal")
#library(rgdal)          #read shapefiles
library(ggpubr)
library(conflicted)
library(sp)
library(shiny)
library(leaflet)
library(shinyWidgets)
conflicts_prefer(dplyr::filter)
conflicts_prefer(dplyr::lag) #try stats if not
library(sf)

df <- read.csv("totalDailyJoin.csv")

lineShp <- raster::shapefile("CTA_RailLines.shp")



#build interactive map visualization
ui2 = fluidPage(
  mainPanel(
    leafletOutput("mymap", height= "89vh")
  ),
  
  #Specify panel attributes
  absolutePanel(top = 10, right = 40, width = "32vw",style = "background-color: white;
                            opacity: 0.85;
                            padding: 20px 20px 20px 20px;
                            margin: auto;
                            border-radius: 5pt;
                            box-shadow: 0pt 0pt 6pt 0px rgba(61,59,61,0.48);
                            padding-bottom: 2mm;
                            padding-top: 1mm;",
                          
                
                #add title and intro text
                fluidRow(
                  column(12,
                         align = "center",
                         tags$p(strong("Precipitation Impacts on Ridership during Sundays/Holidays"), style = "font-size: 3vh;")),
                  br(),
                  column(width = 10,
                         align = "left",
                         tags$div(
                           "Use the slider to explore how CTA ridership changed as a result of precipitation.",
                           br(),
                           
                           "This plot uses data from",
                           tags$a(href="https://www.transitchicago.com/data/", "transitchicago.com"),
                           "the CTA's open",
                           br(),
                           "source data library.",
                           br(),
                           "Also, weather data from: ",
                           tags$a(href = "https://www.meteoblue.com/en/weather/historyclimate/weatherarchive/chicago_united-states_4887398", "meteoblue.com"),
                           br(), br()))),
                #create slider input:
                sliderTextInput("category", "Amount of Rain",
                                choices = c(as.numeric(unique(df$sumPrecip))),
                                selected = range(vals = c(as.numeric(unique(df$sumPrecip))))),
                pickerInput("cat", label = "Select Train Line", 
                            choices = unique(df$genLineType),
                            selected = unique(df$genLineType),
                            multiple = TRUE,
                            options = pickerOptions(
                              actionBox = TRUE,
                              #If all train lines are selected, show 'All Train Lines'
                              selectedTextFormat = paste0("count > ", length(sort(unique(df$genLineType))) -1),
                              countSelectedText = "All Train Lines"))
  ))

server2 = function(input, output, server){
  sliderChoice = reactive({
    dfSub = df|>
      filter(sumPrecip == input$category)
  })
  shapeData = reactive({
    lineShp[lineShp@data$gnLnTyp %in% input$cat,]
  })
  #Create map
  output$mymap <- renderLeaflet({
    
    #Create a palette & corresponding legend
    pal <- colorQuantile("Reds", sliderChoice()$rides, n = 5)
    palColors <- unique(pal(sort(sliderChoice()$rides))) 
    palBreaks <- round(quantile(sliderChoice()$rides, seq(0, 1, .2)),0)
    palLabels <- paste(lag(palBreaks), palBreaks, sep = " - ")[-1] # first lag is NA
    
    
    myMap <- leaflet()%>% #filters our data based on dropdown selection
      addProviderTiles(providers$CartoDB.Positron)%>% #adds a basemap
      addPolylines(data = shapeData(), color = "Gray")%>%
      addCircleMarkers(data = sliderChoice(),
                       ~Long, ~Lat,
                       radius = sliderChoice()$rides/1100,
                       label = ~STATION_DESCRIPTIVE_NAME)
  })
}


shinyApp(ui = ui2, server = server2)
